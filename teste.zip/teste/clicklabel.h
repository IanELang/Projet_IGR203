#ifndef CLICKLABEL_H
#define CLICKLABEL_H

#include <QLabel>

class clickLabel : public QLabel
{
    Q_OBJECT
public:
    explicit clickLabel( const QString& text="", QWidget* parent=0 );

    void enterEvent(QEvent *ev) override
    {
        setStyleSheet("QLabel { background-color : #999; }");

      //  this->
        emit hover();
    }

    void leaveEvent(QEvent *ev) override
    {
        setStyleSheet("QLabel { background-color : #DDA0DD; }");
    }

    ~clickLabel();
signals:
    void clicked();
    void hover();
protected:
    void mousePressEvent(QMouseEvent* event);
};

#endif // CLICKLABEL_H
