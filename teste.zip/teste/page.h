#ifndef PAGE_H
#define PAGE_H

#include "note.h"

#include <QString>
#include <QDate>
#include <QVector>
#include <QDataStream>
#include "clicklabel.h"
#include <iostream>
#include <QToolTip>


class Page : public clickLabel
{
  //  Q_OBJECT

public:
    Page();
    Page(QString  nome); // esse eh o nome do caderno??!!

    friend class MainWindow;
    friend QDataStream &operator<<(QDataStream & stream, const Page &page);
    friend QDataStream &operator>>(QDataStream & stream, Page &page);

//    QVector<Note> notes;
//    QDate creationDate;
//    QString summary;
   //  clickLabel *label;

     // quando o mouse estiver em cima do label ,mostra esse texto
     QToolTip *tt; // setar com o comeco da nota?
     QString texto;
     QString sujet;
     QString pequenoTexto;
     QString keyword;


public slots:
     void teste();

};

//QDataStream &operator<<(QDataStream & stream, const Page &page);
//QDataStream &operator>>(QDataStream & stream, Page &page);

#endif // PAGE_H
