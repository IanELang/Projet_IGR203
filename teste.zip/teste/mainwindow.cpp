#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include "day.h"
#include "calendar.h"

#include "page.h"


#include "clicklabel.h"
#include <QGridLayout>
#include <QDate>
#include <QLabel>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <iostream>
#include <map>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    //    ui->setupUi(this);

    QDate *data = new QDate();
    QWidget * tela = new QWidget();

    this->setCentralWidget(tela);


    tela->setMinimumWidth(840);
    tela->setMinimumHeight(600);

    tela->setMaximumWidth(840);
    tela->setMaximumHeight(600);

    QVBoxLayout * layout = new QVBoxLayout();
    QHBoxLayout * jours = new QHBoxLayout();
    //   QHBoxLayout * boutons = new QHBoxLayout();


    QGridLayout * grid = new QGridLayout();
    tela->setLayout(layout);

    //  layout->addLayout(boutons);
    layout->addLayout(jours);
    layout->addLayout(grid);

    //    boutons->setAlignment(Qt::AlignCenter);
    //    QPushButton  * calendrier = new QPushButton("Calendrier");
    //    QPushButton  * cahiers = new QPushButton("Cahiers");

    //    boutons->addWidget(cahiers);
    //    boutons->addWidget(calendrier);

    //  connect(calendrier, SIGNAL(clicked()), )

    QLabel * lundi = new QLabel("Lundi");
    QLabel * mardi = new QLabel("Mardi");
    QLabel * mercredi = new QLabel("Mercredi");
    QLabel * jeudi = new QLabel("Jeudi");
    QLabel * vendredi = new QLabel("Vendredi");
    QLabel * samedi = new QLabel("Samedi");
    QLabel * dimanche = new QLabel("Dimanche");


    jours->addWidget(lundi,1);
    jours->addWidget(mardi,1);
    jours->addWidget(mercredi,1);
    jours->addWidget(jeudi,1);
    jours->addWidget(vendredi,1);
    jours->addWidget(samedi,1);
    jours->addWidget(dimanche,1);


    Calendar *cal = new Calendar();

    int minHeight = 120;
    int minmWidth = 120;

    // grid->setGeometry(QRect(0,0,1800,1800));
    grid->setHorizontalSpacing(4);
    grid->setVerticalSpacing(4);

    grid->setRowMinimumHeight(1, minHeight);
    grid->setRowMinimumHeight(2, minHeight);
    grid->setRowMinimumHeight(3, minHeight);
    grid->setRowMinimumHeight(4, minHeight);
    grid->setRowMinimumHeight(5, minHeight);

    grid->setColumnMinimumWidth(1, minmWidth);
    grid->setColumnMinimumWidth(2, minmWidth);
    grid->setColumnMinimumWidth(3, minmWidth);
    grid->setColumnMinimumWidth(4, minmWidth);
    grid->setColumnMinimumWidth(5, minmWidth);
    grid->setColumnMinimumWidth(6, minmWidth);
    grid->setColumnMinimumWidth(7, minmWidth);



    int a = data->currentDate().day();

    int colonne = data->currentDate().dayOfWeek(); // 7
    int aux= colonne - (a -1) % 7;
    int ligne = a%7 -1;
    for ( int i=1; i<= data->currentDate().daysInMonth(); i++){


        QString s = QString::number(i);


        Day * d = new Day();
        d->setDay(i, ligne, aux);
        cal->addDay(d);

        grid->addWidget(d, ligne, aux);


        //   grid->addWidget(dia, ligne, aux);
        //std::cout << ligne << " " << aux << std::endl;

        //  cal->addDay(i, ligne, aux);


        aux++;

        if (aux == 8){
            aux = 1;
            ligne++;
        }
        else if (aux == 0){
            aux = 7;
            ligne--;
        }

    }


    clickLabel *nota = new clickLabel("hm");

    QPushButton  * b = new QPushButton("test");

    layout->addWidget(b);
    // connect(nota, SIGNAL(clicked()), this, SLOT (testinho()));

    QLabel *nota3 = new QLabel("aula imageem");

    QLabel *nota2 = new QLabel("aula dsadadsdasdasda");
    QLabel *nota4 = new QLabel("aula ");


    cal->addNote(9, nota);
    cal->addNote(9, nota2);
    cal->addNote(9, nota4);

    cal->addNote(14, nota3);



    // quando cria uma pagina, precisa do nome do caderno, tem-se um label

    Page *pag= new Page("IGR 203");

    cal->addNote(10, pag);

    // nao funciona, nao sei porque
    //  connect(pag->label, SIGNAL(clicked()), pag, SLOT (teste()));

    // deveria abrir a nota do obj clicado
    connect(pag, SIGNAL(clicked()), this, SLOT (teste()));

    // esse texto precisa ser definido na classe pag?
    //  pag->setToolTip("Sujet: IGR 203 \nProfesseur: James \nTitre: IHM\n // colocar um pequeno resumo da nota? primeiras palavras ");
    pag->setToolTip(pag->pequenoTexto);


    QToolTip * tt;
    //    QFont serifFont("Helvetica", 16, QFont::Normal);
    QFont sansFont("Helvetica [Cronyx]", 16);

    //    pag->setToolTip( QApplication::translate(__FUNCTION__, "    <html>\n"
    //                                                          "    <div style=\"width: 300px;\">ea ea ea ea ea ea ea ea ea ea ea ea ea ea ea ea ea ea ea ea ea</div>"
    //                                                          "    </html>", 0
    //                                         ));
    tt->setFont(sansFont);

    QPalette palette = QToolTip::palette();
    palette.setColor(QPalette::ToolTipBase,QColor("#F6F6F6")); // light grey
    palette.setColor(QPalette::ToolTipText,QColor("#706F6F"));//dark grey for text
    QToolTip::setPalette(palette);

    QToolTip::showText(pag->mapFromGlobal(QPoint()), pag->toolTip());


}

void MainWindow:: teste(){
    // abre a pagina da nota
    std::cout << "clicou - abriu as notas -> abriu a pagina" << std::endl;
}


void MainWindow:: mostrar(){
    // abre a pagina da nota
    // std::cout << "clicou - abriu as notas -> abriu a pagina" << std::endl;
}


MainWindow::~MainWindow()
{
    delete ui;
}
