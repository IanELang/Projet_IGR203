#include "clicklabel.h"

clickLabel::clickLabel(const QString& text, QWidget* parent)
    : QLabel(parent)
{
    setText(text);
}

clickLabel::~clickLabel()
{
}

void clickLabel::mousePressEvent(QMouseEvent* event)
{
    emit clicked();
}
