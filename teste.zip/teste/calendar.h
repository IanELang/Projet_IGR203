#ifndef CALENDAR_H
#define CALENDAR_H

#include <vector>
#include "day.h"
#include <iostream>

class Calendar
{
public:
    Calendar();
    std::vector<Day*> days;

    void getCalendarPos(int day, int *ligne, int * colonne){
        if(days.size() != 0){
            for(unsigned int i = 0; i < days.size(); i++){
                if(days[i]->number == day){
                    *ligne = days[i]->calendarLine;
                    *colonne = days[i]->calendarColumn;
                }
            }

            std::cout << day << " " << *ligne << " " << *colonne << std::endl;
        }

    }

    void addNote(int day, QLabel *nota){
        if(days.size() != 0){
            for(unsigned int i = 0; i < days.size(); i++){
                if(days[i]->number == day){
                    days[i]->addNoteWidget(nota);

                }
            }
        }

    }

    void addDay(int day, int line, int colonne){
        Day * d = new Day();
        d->number = day;
        d->calendarLine = line;
        d->calendarColumn = colonne;
        days.push_back(d);
        //days.push_back(new Day(day, line, colonne));
    }

    void addDay(Day *d){
        days.push_back(d);
    }
};

#endif // CALENDAR_H
