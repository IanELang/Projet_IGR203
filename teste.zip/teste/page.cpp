#include "page.h"

Page::Page()
{
}

Page::Page(QString nome)
{
 //   label = new clickLabel(nome);
    this->setText(nome);
    texto = "Dsadasd sad adas das djsajdi oasj dasm doasjio dosa saiodjhsao jopask jdosajd oas\n dasdasbdasdbsahjdbsajdbashjdsa \n dsahdusahduisahduiashdias \n ";
    sujet = "Nom du cours";
    keyword = "mot-cle";
    pequenoTexto = "Sujet: " + sujet+ "\n"+ "Mots-clés: " + keyword + "\n" + texto.mid(0,100);

}

void Page:: teste(){
    std::cout << "clicou" << std::endl;
}

//QDataStream &operator<<(QDataStream & stream, const Page &page)
//{
//    return stream << page.notes << page.creationDate << page.summary;
//}


//QDataStream &operator>>(QDataStream & stream, Page &page)
//{
//    return stream >> page.notes >> page.creationDate >> page.summary;
//}
